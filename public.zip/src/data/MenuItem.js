export const MenuItems = [
  {
    title: "Birthday & Gifts",
    path: "/birthday-gifts",
    cName: "dropdown-link",
  },
  {
    title: "Clothes & Fashion",
    path: "/clothes-fashion",
    cName: "dropdown-link",
  },
  {
    title: "Summer Sales",
    path: "/summer-sales",
    cName: "dropdown-link",
  },
];
